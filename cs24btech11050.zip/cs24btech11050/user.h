#define SBRK_ERROR ((char *)-1)

struct stat;
struct mlfqinfo;
// system calls
int fork(void);
int exit(int) __attribute__((noreturn));
int wait(int*);
int pipe(int*);
int write(int, const void*, int);
int read(int, void*, int);
int close(int);
int kill(int);
int exec(const char*, char**);
int open(const char*, int);
int mknod(const char*, short, short);
int unlink(const char*);
int fstat(int fd, struct stat*);
int link(const char*, const char*);
int mkdir(const char*);
int chdir(const char*);
int dup(int);
int getpid(void);
char* sys_sbrk(int,int);
int pause(int);
int uptime(void);
// _begin
int hello(void);
int getpid2(void);
int getppid(void);
int getnumchild(void);
int getsyscount(void);
int getchildsyscount(int pid);
int getlevel(void);
int getmlfqinfo(int pid, struct mlfqinfo *info);
// _end

// ulib.c
int stat(const char*, struct stat*);
char* strcpy(char*, const char*);
void *memmove(void*, const void*, int);
char* strchr(const char*, char c);
int strcmp(const char*, const char*);
char* gets(char*, int max);
uint strlen(const char*);
void* memset(void*, int, uint);
int atoi(const char*);
int memcmp(const void *, const void *, uint);
void *memcpy(void *, const void *, uint);
char* sbrk(int);
char* sbrklazy(int);

// printf.c
void fprintf(int, const char*, ...) __attribute__ ((format (printf, 2, 3)));
void printf(const char*, ...) __attribute__ ((format (printf, 1, 2)));

// umalloc.c
void* malloc(uint);
void free(void*);

struct mlfqinfo {
    int level; // current queue level
    int ticks[4]; // total ticks consumed at each level
    int times_scheduled; // number of times the process has been scheduled
    int total_syscalls; // total system calls made (from PA1)
};